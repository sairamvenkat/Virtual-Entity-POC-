﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ContactsAPI.Connections
{
    public static class Connections
    {
        public static SqlConnectionStringBuilder connectToDB()
        {
            var cb = new SqlConnectionStringBuilder();
            cb.DataSource = "saiazuresqlserver.database.windows.net";
            cb.UserID = "sairamvenkat";
            cb.Password = "Microsoft1@";
            cb.InitialCatalog = "Salesforce";
            cb.MultipleActiveResultSets = true;
            return cb;
        }
    }
}
