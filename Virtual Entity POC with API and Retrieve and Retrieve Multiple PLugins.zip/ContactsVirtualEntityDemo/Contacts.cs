﻿//using Microsoft.IdentityModel.Tokens;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Extensions;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace SalesForceContactsVirtualEntityDemo
{
    public class Contacts
    {
        public string FIRSTNAME { get; set; }
        public string LASTNAME { get; set; }
        public bool ISFAMILYMEMBER { get; set; }
        public string GENDER { get; set; }
        public string EMAIL { get; set; }
        public string PHONENUMBER { get; set; }
        public DateTime DATEOFBIRTH { get; set; }
        public string CONTACTID { get; set; }
        public string ROLE { get; set; }
        public Guid ID { get; set; }
    }

    public class CallAPI
    {
        public static List<Contacts> ContactsList { get; set; }
        public static List<Contacts> ContactsList1 { get; set; }

        public static async Task<List<Contacts>> getAllAsync(ITracingService tracer)
        {
            using (HttpClient client = HttpHelper.GetHttpClient())
            {
                string url = "https://salesforcecontacts.azurewebsites.net/api/contacts";

                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, new Uri(url));
                HttpResponseMessage response = await client.SendAsync(request);
                string json = response.Content.ReadAsStringAsync().Result;
                // tracer.Trace($"JSON:{json}");
                return JsonConvert.DeserializeObject<List<Contacts>>(json);
            }
        }

        public static async Task<List<Contacts>> getbyIdAsync(ITracingService tracer, [Optional] string SearchKeyWord)
        {
            using (HttpClient client = HttpHelper.GetHttpClient())
            {
                //tracer.Trace($"SearchKeyWord In getbyIdAsync : {SearchKeyWord}");
                string url = "";
                if (string.IsNullOrEmpty(SearchKeyWord))
                    url = $"https://salesforcecontacts.azurewebsites.net/api/contacts";
                else
                    url = $"https://salesforcecontacts.azurewebsites.net/api/contacts/{SearchKeyWord}";
                //tracer.Trace($"URL : {url}");
                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, new Uri(url));
                HttpResponseMessage response = await client.SendAsync(request);
                string json = response.Content.ReadAsStringAsync().Result;
                // tracer.Trace($"Retrieve By Id Response : {json}");
                return JsonConvert.DeserializeObject<List<Contacts>>(json);
            }
        }
    }

    public class SFCustomConnectorRetrieve : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            ITracingService tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IOrganizationServiceFactory serviceFactory =
        (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            List<Contacts> conts = new List<Contacts>();
            var data = Task.Run(async () => await CallAPI.getbyIdAsync(tracingService));
            Task.WaitAll(data);

            conts = data.Result;

            //tracingService.Trace($"Contacts:{JsonConvert.SerializeObject(conts?.ToList())}");
            var item = conts?.FirstOrDefault(d => d.ID == context.PrimaryEntityId);
          //  tracingService.Trace($"context.PrimaryEntityId : {context.PrimaryEntityId}");
           // conts.ForEach(c=>tracingService.Trace($"conts.Id : {c.ID}"));
            // Map 3rd party data to entity model
            Entity entity = new Entity(context.PrimaryEntityName);
            if (item != null)
            {
                tracingService.Trace("In If");
                entity["ve_contactsid"] = item.ID;
                entity["ve_name"] = item.FIRSTNAME;
                entity["ve_lastname"] = item.LASTNAME;
                entity["ve_phonenumber"] = item.PHONENUMBER;
                entity["ve_email"] = item.EMAIL;
                entity["ve_contactid"] = item.CONTACTID.Trim();
                entity["ve_gender"] = item.GENDER;
            }
            else
            {
                tracingService.Trace("In else");
                entity["ve_contactsid"] = item.ID;
                entity["ve_name"] = item.FIRSTNAME;
                entity["ve_lastname"] = item.LASTNAME;
                entity["ve_phonenumber"] = item.PHONENUMBER;
                entity["ve_email"] = item.EMAIL;
                entity["ve_contactid"] = item.CONTACTID.Trim();
                entity["ve_gender"] = item.GENDER;
            }
           // Set output parameter
            context.OutputParameters["BusinessEntity"] = entity;

        }
    }
    public class SFCustomConnectorRetrieveMultiple : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);
            EntityCollection ec = new EntityCollection();
            try
            {
                QueryExpression query = context.InputParameterOrDefault<QueryExpression>("Query");
                var visitor = new SearchVisitor();
                query.Accept(visitor);
                //tracingService.Trace(visitor.SearchKeyWord);
                //tracingService.Trace($"Searching contacts with Id: {visitor.SearchKeyWord}");
                //tracingService.Trace("Before hitting API");
                var data = Task.Run(async () => await CallAPI.getbyIdAsync(tracingService, visitor.SearchKeyWord));
                //tracingService.Trace($"{data}");
                Task.WaitAll(data);

                foreach (var d in data.Result)
                {
                    Entity entity = new Entity("ve_contacts");
                    //tracingService.Trace($"ID : {d.ID}");
                    entity["ve_contactsid"] = d.ID;
                    entity["ve_name"] = d.FIRSTNAME;
                    entity["ve_lastname"] = d.LASTNAME;
                    entity["ve_phonenumber"] = d.PHONENUMBER;
                    entity["ve_email"] = d.EMAIL;
                    entity["ve_contactid"] = d.CONTACTID.Trim();
                    entity["ve_gender"] = d.GENDER;
                    ec.Entities.AddRange(entity);

                    tracingService.Trace($"Before calling QE");
                    QueryExpression qe = new QueryExpression("contact");
                    qe.ColumnSet.AddColumns("contactid", "new_contactid_ve");
                    qe.Criteria.AddCondition("new_contactid_ve", ConditionOperator.Equal, d.CONTACTID.Trim());
                    EntityCollection contactec = service.RetrieveMultiple(qe);
                    tracingService.Trace($"EC Count : {contactec.Entities.Count}");
                    if (contactec.Entities.Count > 0)
                    {
                        Entity conet = contactec.Entities.FirstOrDefault();
                        tracingService.Trace($" CONTACTID :{d.CONTACTID.Trim()}");
                        tracingService.Trace($"conet.Id: {conet.Id}");
                        tracingService.Trace($"d.Id: {d.ID}");
                        Entity contact = new Entity("contact");
                        contact["new_virtualcontact"] = new EntityReference("ve_contacts", d.ID);
                        contact["contactid"] = conet.Id;

                        service.Update(contact);
                    }
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }

            tracingService.Trace($"Contacts:{JsonConvert.SerializeObject(CallAPI.ContactsList)}");
            // Set output parameter
            context.OutputParameters["BusinessEntityCollection"] = ec;
        }
    }
}
