function vrContacts(executionContext) {
    var formContext = executionContext.getFormContext();
    var contactidve = null;
    if (formContext.getAttribute("new_contactid_ve").getValue() != null) {
        contactidve = formContext.getAttribute("new_contactid_ve").getValue();
    }
    var subgrid = formContext.getControl("vecontacts");
    subgrid.setFilterXml("<filter><condition attribute='ve_contactid' operator='like' value='" + contactidve + "' /></filter>");
    //Refresh grid to show filtered records only.
    formContext.ui.controls.get("vecontacts").refresh();
}